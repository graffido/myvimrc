
ColorScheme Selector Plugin
===========================
provide emacs-like colorscheme selector buffer.


Commands
========

      :SelectColorS

      :EditCurrentColorS

BufferMapping
=============

*C-q*  - quit window.

*e*    - edit

*C-n*  - apply next

*C-p*  - apply previous

*R*    - fetch new random scheme

*D*    - delete scheme

*?*    - show help

*C-s*  - setup colorscheme

